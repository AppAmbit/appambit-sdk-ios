# iOS-HelloWorld-ObjectiveC
My iOS app playground (Objective C)
Tutorial I followed was this one: [Basic objective-c Programing: Button and Label](https://www.youtube.com/watch?v=gEAAiYGjTMA)

You'll notice that some files have the label `Created by <someone-else-who-is-not-Catzie>` and that's because of the previous owner of the Mac I'm using. He's now in Maldives.
