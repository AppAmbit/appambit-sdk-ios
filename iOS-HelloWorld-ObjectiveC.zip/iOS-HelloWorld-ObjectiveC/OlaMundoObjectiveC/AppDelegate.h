//
//  AppDelegate.h
//  OlaMundoObjectiveC
//
//  Created by Hajji on 26/07/2016.
//  Copyright © 2016 Toncatzu. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

