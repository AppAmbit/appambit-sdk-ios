#import <UIKit/UIKit.h>

@interface ViewController : UIViewController

@property (weak, nonatomic) IBOutlet UITextField *messageField;
@property (weak, nonatomic) IBOutlet UILabel *statusLabel;

// Botones
- (IBAction)generateLogErrorTapped:(id)sender;
- (IBAction)generateUncontrolledErrorTapped:(id)sender;

@end
