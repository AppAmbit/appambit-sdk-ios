// ViewController.m
#import "ViewController.h"
#import <AppAmbitSdk/AppAmbitSdk-Swift.h>  // puente del SDK

@interface ViewController ()
@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    if (self.messageField.text.length == 0) {
        self.messageField.text = @"Test Log Error";
    }
}

#pragma mark - UI helper
- (void)showInfo:(NSString *)message {
    UIAlertController *ac = [UIAlertController alertControllerWithTitle:@"Info"
                                                                message:message
                                                         preferredStyle:UIAlertControllerStyleAlert];
    [ac addAction:[UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleCancel handler:nil]];
    [self presentViewController:ac animated:YES completion:nil];
    if (self.statusLabel) self.statusLabel.text = message;
}

#pragma mark - Botones

// 1) Generar Log Error (equivale a onTestLog() en Swift)
- (IBAction)generateLogErrorTapped:(id)sender {
    NSString *msg = self.messageField.text ?: @"Test Log Error";
    NSDictionary<NSString*, NSString*> *props = @{ @"user_id": @"1" };

    // Usa la firma completa expuesta por el SDK (Swift -> ObjC)
    [Crashes logErrorWithMessage:msg
                       properties:props
                         classFqn:nil
                        exception:nil
                         fileName:nil
                       lineNumber:0
                        createdAt:nil
                       completion:^(NSError * _Nullable error) {
        dispatch_async(dispatch_get_main_queue(), ^{
            if (error) {
                NSLog(@"[ObjC] Error sending Log Error: %@", error.localizedDescription);
                [self showInfo:@"Error sending LogError"];
            } else {
                NSLog(@"[ObjC] Log Error sent successfully");
                [self showInfo:@"LogError Sent"];
            }
        });
    }];
}

// 2) Generar Error NO controlado (solo al presionar el botón)
- (IBAction)generateUncontrolledErrorTapped:(id)sender {
    NSArray *arr = @[];
    __unused id obj = [arr objectAtIndex:10]; // crash intencional (index out of bounds)
    NSLog(@"%@", obj); // nunca se ejecuta
}

@end
